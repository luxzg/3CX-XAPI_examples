This folder will create exportes XVS and XLSX files. If deleted it will be recreated on next export.
